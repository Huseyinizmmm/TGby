<?php
class config{

	public $bot_id             = '1021047882:AAHfCB3Gwbg3FVgHfxlrxnUe9iKNyJ_zxAE'; // توکن ربات
	public $path               = 'https://seenservice.ir/Bots/Vardast/'; // آدرس هاست محل پوشه
	public $database_host      = 'localhost'; // دست نزنید
	public $database_name      = 'cp29693_vardast'; // نام دیتابیس
	public $database_username  = 'cp29693_vardast'; // یوزرنیم
	public $database_password  = 'wUtq&yl+gZnw'; // پسورد
	public $bot_Username       = 'ManagersChannelBot'; // ایدی ربات بدون @
	public $admin_list         = array(201885229,311294439); // ادمین ها بترتیب
	public $CHANNEL_ID         = '@VbazdidGirads'; // ایدی کانال
	public $CHANNEL_LINK       = 'http://t.me/VbazdidGirads'; // لینک کانال
	public $version            = '2.1'; // دست نزنید
	
}

/*
این سورس
توسط : @DevHamidReza
در کانال : @souresphp
باگ گیری شده است.
*/