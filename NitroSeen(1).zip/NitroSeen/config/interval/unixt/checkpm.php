<?php

	/* /usr/bin/php -q /home/sajadhaj/public_html/falBot/checkStatus.php */
	ignore_user_abort(1); // run script in background
	set_time_limit(0); // run script forever 	
	ini_set("log_errors", 0);
	require_once 'autoload.php';
	date_default_timezone_set('Asia/Tehran');
	
	if(file_get_contents("config/order.txt")=="1")
	{
		$rows = $database->query("SELECT * FROM `list` where status=0 and ch_name='unixt' order by rand() limit ".file_get_contents("config/count.txt"))->fetchAll();
	}
	else if(file_get_contents("config/order.txt")=="2")
	{
		$rows = $database->query("SELECT * FROM `list` where status=0 and ch_name='unixt' order by id DESC limit ".file_get_contents("config/count.txt"))->fetchAll();
	}
	else
	{	
		$rows = $database->query("SELECT * FROM `list` where status=0 and ch_name='unixt' order by id ASC limit ".file_get_contents("config/count.txt"))->fetchAll();
	}
	
	for($j=0;$j<=sizeof($rows);$j++)
	{
		$timeSend=explode("-",file_get_contents("config/time.txt"));
		if(jdate('H:i','','','','en')>=$timeSend[0] && jdate('H:i','','','','en')<=$timeSend[1])
		{
			if($rows[$j]['ch_name']==0)
			{
				if($rows[$j]['file_id'] != '0')
				{	
					$caption = str_replace("????","",$rows[$j]['caption']);
					//////////////////////
					if(file_get_contents("config/signature.txt")=="1")
					{
						$sign = $database->select('channel', ['signature'], ['channel' => $rows[$j]['ch_name']]);
						
					if($sign[0]['signature']!="0")
					{
						$text=$caption."\n".$sign[0]['signature'];
						if(strlen($caption)>=400)
						{
							$textSend=$caption;
						}
						else
						{					
							if(strlen($text)>=400)
							{
								$textSend=$caption;
							}
							else{
								$textSend=$text;
							}
						}
					}
					else
					{
						$textSend=$caption;
					}
				}
				else
				{
					$textSend=$caption;
				}
				
				/////////////////////
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$telegram->sendDocument([
				'chat_id' => "@".$rows[$j]['ch_name'],
				'document' =>  $rows[$j]['file_id'],
				'caption' =>  $textSend ,
				"parse_mode" =>"HTML",
				'disable_notification' =>  $notificationStatus ,
				'disable_web_page_preview' => $linkStatus
				]);
				
				$database->update("list", [ 'status' => 1], [ 'id' => $rows[$j]['id']]);
			}
			else if($rows[$j]['video_id'] != '0')
			{			
				$caption = str_replace("????","",$rows[$j]['caption']);
				//////////////////////
				if(file_get_contents("config/signature.txt")=="1")
				{
					$sign = $database->select('channel', ['signature'], ['channel' => $rows[$j]['ch_name']]);
					
					if($sign[0]['signature']!="0")
					{
						$text=$caption."\n".$sign[0]['signature'];
						if(strlen($caption)>=400)
						{
							$textSend=$caption;
						}
						else
						{					
							if(strlen($text)>=400)
							{
								$textSend=$caption;
							}
							else{
								$textSend=$text;
							}
						}
					}
					else
					{
						$textSend=$caption;
					}
				}
				else
				{
					$textSend=$caption;
				}			
				/////////////////////
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$telegram->sendVideo([
				'chat_id' => "@".$rows[$j]['ch_name'],
				'video' =>  $rows[$j]['video_id'],
				'caption' =>  $textSend ,
				"parse_mode" =>"HTML",
				'disable_notification' =>  $notificationStatus ,
				'disable_web_page_preview' => $linkStatus
				]);
				
				$database->update("list", [ 'status' => 1], [ 'id' => $rows[$j]['id']]);	
			}
			else if($rows[$j]['photo_id'] != '0' and file_get_contents("config/watermark.txt") == '0')
			{						
				$caption = str_replace("????","",$rows[$j]['caption']);
				//////////////////////
				if(file_get_contents("config/signature.txt")=="1")
				{
					$sign = $database->select('channel', ['signature'], ['channel' => $rows[$j]['ch_name']]);
					
					if($sign[0]['signature']!="0")
					{
						$text=$caption."\n".$sign[0]['signature'];
						if(strlen($caption)>=400)
						{
							$textSend=$caption;
						}
						else
						{					
							if(strlen($text)>=400)
							{
								$textSend=$caption;
							}
							else{
								$textSend=$text;
							}
						}
					}
					else
					{
						$textSend=$caption;
					}
				}
				else
				{
					$textSend=$caption;
				}			
				/////////////////////
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$telegram->sendPhoto([
				'chat_id' => "@".$rows[$j]['ch_name'],
				'photo' =>  $rows[$j]['photo_id'],
				'caption' =>  $textSend ,
				"parse_mode" =>"HTML",
				'disable_notification' =>  $notificationStatus ,
				'disable_web_page_preview' => $linkStatus
				]);
				
				$database->update("list", [ 'status' => 1], [ 'id' => $rows[$j]['id']]);
			}
			else if($rows[$j]['photo_id'] != '0' and file_get_contents("config/watermark.txt") == '1')
			{//watermark	
				
				$getfile='https://api.telegram.org/bot'.$auth->bot_id.'/getFile?file_id='.$rows[$j]['photo_id'];
				$getfile=file_get_contents($getfile);
				$file=json_decode($getfile, true);
				$SourceFile='https://api.telegram.org/file/bot'.$auth->bot_id.'/'.$file['result']['file_path'];
				
				$DestinationFile = 'images/'.$rows[$j]['ch_name'].'_'.$rows[$j]['id'].'_'.time().'.jpg'; 
				$WaterMarkText = "@".$rows[$j]['ch_name'];
				
				$jpg_image = imagecreatefromjpeg($SourceFile);
				$color= imagecolorallocate($jpg_image, 255, 255, 255);
				$font_path = 'config/arial.ttf';
				$bbox = imagettfbbox(25, 0, $font_path, $watermarktext);
				$x = $bbox[0] + (imagesx($jpg_image)) - ($bbox[4] / 2) - 130;//130 for left
				$y = $bbox[1] + (imagesy($jpg_image)) - ($bbox[5] / 2) - 40;//30 for bottom
				imagettftext($jpg_image, 25, 0, $x, $y, $color, $font_path, $WaterMarkText);
				header('Content-type: image/jpeg');
				imagejpeg($jpg_image, $DestinationFile, 100);
				imagedestroy ($jpg_image);
				
				$caption = str_replace("????","",$rows[$j]['caption']);
				//////////////////////
				if(file_get_contents("config/signature.txt")=="1")
				{
					$sign = $database->select('channel', ['signature'], ['channel' => $rows[$j]['ch_name']]);
					
					if($sign[0]['signature']!="0")
					{
						$text=$caption."\n".$sign[0]['signature'];
						if(strlen($caption)>=400)
						{
							$textSend=$caption;
						}
						else
						{					
							if(strlen($text)>=400)
							{
								$textSend=$caption;
							}
							else{
								$textSend=$text;
							}
						}
					}
					else
					{
						$textSend=$caption;
					}
				}
				else
				{
					$textSend=$caption;
				}				
				/////////////////////
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$telegram->sendPhoto([
				'chat_id' => "@".$rows[$j]['ch_name'],
				'photo' =>  $auth->path.$DestinationFile,
				'caption' =>  $textSend ,
				"parse_mode" =>"HTML",
				'disable_notification' =>  $notificationStatus ,
				'disable_web_page_preview' => $linkStatus
				]);
				
				$database->update("list", [ 'status' => 1], [ 'id' => $rows[$j]['id']]);	
				unlink($DestinationFile);
			}
			else if($rows[$j]['audio_id'] != '0')
			{			
				$caption = str_replace("????","",$rows[$j]['caption']);
				//////////////////////
				if(file_get_contents("config/signature.txt")=="1")
				{
					$sign = $database->select('channel', ['signature'], ['channel' => $rows[$j]['ch_name']]);
					
					if($sign[0]['signature']!="0")
					{
						$text=$caption."\n".$sign[0]['signature'];
						if(strlen($caption)>=400)
						{
							$textSend=$caption;
						}
						else
						{					
							if(strlen($text)>=400)
							{
								$textSend=$caption;
							}
							else{
								$textSend=$text;
							}
						}
					}
					else
					{
						$textSend=$caption;
					}
				}
				else
				{
					$textSend=$caption;
				}			
				/////////////////////
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$telegram->sendAudio([
				'chat_id' => "@".$rows[$j]['ch_name'],
				'audio' =>  $rows[$j]['audio_id'],
				'caption' =>  $textSend ,
				"parse_mode" =>"HTML",
				'disable_notification' =>  $notificationStatus ,
				'disable_web_page_preview' => $linkStatus
				]);
				
				$database->update("list", [ 'status' => 1], [ 'id' => $rows[$j]['id']]);	
			}
			else if($rows[$j]['sticker_id'] != '0')
			{
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$telegram->sendSticker([
				'chat_id' => "@".$rows[$j]['ch_name'],
				'sticker' =>  $rows[$j]['sticker_id'],
				"parse_mode" =>"HTML",
				'disable_notification' =>  $notificationStatus ,
				'disable_web_page_preview' => $linkStatus
				]);
				
				$database->update("list", [ 'status' => 1], [ 'id' => $rows[$j]['id']]);
			}
			else if($rows[$j]['voice_id'] != '0')
			{			
				$caption = str_replace("????","",$rows[$j]['caption']);
				//////////////////////
				if(file_get_contents("config/signature.txt")=="1")
				{
					$sign = $database->select('channel', ['signature'], ['channel' => $rows[$j]['ch_name']]);
					
					if($sign[0]['signature']!="0")
					{
						$text=$caption."\n".$sign[0]['signature'];
						if(strlen($caption)>=400)
						{
							$textSend=$caption;
						}
						else
						{					
							if(strlen($text)>=400)
							{
								$textSend=$caption;
							}
							else{
								$textSend=$text;
							}
						}
					}
					else
					{
						$textSend=$caption;
					}
				}
				else
				{
					$textSend=$caption;
				}			
				/////////////////////
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$telegram->sendVoice([
				'chat_id' => "@".$rows[$j]['ch_name'],
				'voice' =>  $rows[$j]['voice_id'],
				'caption' =>  $textSend ,
				"parse_mode" =>"HTML",
				'disable_notification' =>  $notificationStatus ,
				'disable_web_page_preview' => $linkStatus
				]);
				
				$database->update("list", [ 'status' => 1], [ 'id' => $rows[$j]['id']]);	
			}
			else if($rows[$j]['location_long'] != '0' && $rows[$j]['location_lat'] != '0')
			{
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$telegram->sendLocation([
				'chat_id' => "@".$rows[$j]['ch_name'],
				'latitude' =>  $rows[$j]['location_lat'],
				'longitude' =>  $rows[$j]['location_long'] ,
				'disable_notification' =>  $notificationStatus ,
				'disable_web_page_preview' => $linkStatus
				]);
				
				$database->update("list", [ 'status' => 1], [ 'id' => $rows[$j]['id']]);		
			}			
			else
			{
				$caption = str_replace("????","",$rows[$j]['caption']);	
				//////////////////////
				if(file_get_contents("config/signature.txt")=="1")
				{
					$sign = $database->select('channel', ['signature'], ['channel' => $rows[$j]['ch_name']]);
					
					if($sign[0]['signature']!="0")
					{
						$textSend=$caption."\n".$sign[0]['signature'];
					}
					else
					{
						$textSend=$caption;
					}
				}
				else
				{
					$textSend=$caption;
				}			
				/////////////////////	
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$telegram->sendMessage([
				'chat_id' => "@".$rows[$j]['ch_name'],
				'text' =>  $textSend,
				"parse_mode" =>"HTML",
				'disable_notification' =>  $notificationStatus ,
				'disable_web_page_preview' => $linkStatus
				]);
				
				$database->update("list", [ 'status' => 1], [ 'id' => $rows[$j]['id']]);	
			}
		}
		else
		{
			$json = $telegram->forwardMessage([
			'chat_id' => "@".$rows[$j]['ch_name'],
			'from_chat_id' => $rows[$j]['admin_id'],
			'message_id' => $rows[$j]['msg_id'],
			"parse_mode" =>"HTML",
			'disable_notification' =>  $notificationStatus ,
			'disable_web_page_preview' => $linkStatus
			]);
			$database->update("list", [ 'status' => 1], [ 'id' => $rows[$j]['id']]);	
		}
	}
}	

?>