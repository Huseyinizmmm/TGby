<?php
	require_once dirname(__FILE__) . '/../../../autoload.php';
	
	function convertNumbers($srting,$toPersian=false)
	{
		$en_num = array('0','1','2','3','4','5','6','7','8','9');
		$fa_num = array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹');
		if($toPersian)
		return str_replace($en_num, $fa_num, $srting);
        else 
		return str_replace($fa_num, $en_num, $srting);
	}
	
	if(in_array($data->user_id, $auth->admin_list))
	{
		if ( $constants->last_message === null ) 
		{
			$database->update("member", [ 'last_query' => 'countPost' ],["id" => $data->user_id]);
			$telegram->sendMessage([
			'chat_id' => $data->chat_id,
			'text' => "📑 تنظیم تعداد مطلب ارسالی از صف در هر بار ارسال"."\n\n"."مطالبی که در صف ارسال هستند، در فواصل زمانی که شما تعیین می‌کنید، به کانال شما ارسال می‌شود"."\n"."اما ربات این امکان را دارد که در زمان ارسال مطلب از صف، بجای ۱ مطلب، مثلا ۵ مطلب را بفرستد!"."\n\n"."دوست دارید چند مطلب از صف در هر مرتبه به کانال ارسال شود؟"."\n"."می‌توانید عددی بین ۱ تا ۲۰ را بفرستید."."\n"."مثلا اگر عدد ۵ را بفرستید، به معنای این است که هرگاه زمان ارسال از صف برسد، ۵ مطلب با هم از صف شما ارسال می‌شود"."\n\n"."در حال حاضر تنظیم صف روی ".file_get_contents("config/count.txt")." مطلب در هربار ارسال از صف است",
			'reply_markup' => $keyboard->go_back()
			]);
		}
		elseif ( $constants->last_message == 'countPost' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "گزینه مورد نظر را انتخاب نمایید:",
				'reply_markup' => $keyboard->key_setting()
				]);
			} 
			else 
			{
				if(is_numeric(convertNumbers($data->text)) && convertNumbers($data->text)<=20 && convertNumbers($data->text)>0)
				{
					$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
					
					file_put_contents("config/count.txt",convertNumbers($data->text));
					
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'parse_mode' => 'Markdown',
					'text' => "✅ تعداد جدید باموفقیت ثبت شد.",
					'reply_markup' => $keyboard->key_setting()
					]);
				}
				else
				{
					$database->update("member", [ 'last_query' => 'countPost' ],["id" => $data->user_id]);
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'text' => "⚠️ حداکثر مجاز 20  و حداقل 1 می باشد."."\n\n"."📑 تنظیم تعداد مطلب ارسالی از صف در هر بار ارسال"."\n\n"."مطالبی که در صف ارسال هستند، در فواصل زمانی که شما تعیین می‌کنید، به کانال شما ارسال می‌شود"."\n"."اما ربات این امکان را دارد که در زمان ارسال مطلب از صف، بجای ۱ مطلب، مثلا ۵ مطلب را بفرستد!"."\n\n"."دوست دارید چند مطلب از صف در هر مرتبه به کانال ارسال شود؟"."\n"."می‌توانید عددی بین ۱ تا ۲۰ را بفرستید."."\n"."مثلا اگر عدد ۵ را بفرستید، به معنای این است که هرگاه زمان ارسال از صف برسد، ۵ مطلب با هم از صف شما ارسال می‌شود"."\n\n"."در حال حاضر تنظیم صف روی ".file_get_contents("config/count.txt")." مطلب در هربار ارسال از صف است",
					'reply_markup' => $keyboard->go_back()
					]);
				}
			}
		}
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML",
		'reply_markup' => $keyboard->key_start()
		]);
	}
 