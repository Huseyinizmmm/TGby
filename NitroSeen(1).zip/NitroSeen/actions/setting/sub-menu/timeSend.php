<?php
	require_once dirname(__FILE__) . '/../../../autoload.php';
	
	function convertNumbers($srting,$toPersian=false)
	{
		$en_num = array('0','1','2','3','4','5','6','7','8','9');
		$fa_num = array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹');
		if($toPersian)
		return str_replace($en_num, $fa_num, $srting);
        else 
		return str_replace($fa_num, $en_num, $srting);
	}
	
	if(in_array($data->user_id, $auth->admin_list))
	{
		if ( $constants->last_message === null ) 
		{
			$database->update("member", [ 'last_query' => 'timeSend' ],["id" => $data->user_id]);
			$telegram->sendMessage([
			'chat_id' => $data->chat_id,
			'text' => "⏰ مطالب موجود در «صف» طبق تنظیم زمانی شما در تمام طول ۲۴ ساعت شبانه‌روز ارسال می‌شود"."\n\n"."اما برخی مدیران (برای عدم مزاحمت شبانه یا توقف ارسال هرگونه مطلب به کانال بخاطر تبادلات تلگرامی و ...) مایل نیستند که مطالب موجود در صف، در ساعات شبانگاهی ارسال گردد"."\n"."در صورتی که می‌خواهید این تنظیم را تغییر دهید، می‌توانید از بین زمان‌های پیشنهادی زیر، یکی را انتخاب کنید یا زمان موردنظر خود را تایپ و ارسال کنید"."\n\n"."دقت کنید که حتما باید زمان مورد نظر به صورت ساعت ۲۴ ساعته باشد"."\n"."ابتدا ساعت شروع و سپس خط تیره و سپس ساعت انتهایی را ارسال کنید"."\n\n"."🔴 به عنوان مثال: "."\n"."08:00-23:00"."\n\n"."تنظیم فعلی شما : "."\n".file_get_contents("config/time.txt"),
			'reply_markup' => $keyboard->go_back()
			]);
		}
		elseif ( $constants->last_message == 'timeSend' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "گزینه مورد نظر را انتخاب نمایید:",
				'reply_markup' => $keyboard->key_setting()
				]);
			} 
			else 
			{
				$dataTime=explode("-",$data->text);
				if($dataTime[0]!=null && $dataTime[1]!=null && ($dataTime[0] < $dataTime[1]) && strlen($dataTime[0])<6 && strlen($dataTime[1])<6 )
				{
					$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
					
					file_put_contents("config/time.txt",$data->text);
					
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'parse_mode' => 'Markdown',
					'text' => "✅ زمان جدید باموفقیت ثبت شد.",
					'reply_markup' => $keyboard->key_setting()
					]);
				}
				else
				{
					$database->update("member", [ 'last_query' => 'timeSend' ],["id" => $data->user_id]);
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'text' => "⚠️ ورودی صحیح نمی باشد!"."\n\n"."⏰ مطالب موجود در «صف» طبق تنظیم زمانی شما در تمام طول ۲۴ ساعت شبانه‌روز ارسال می‌شود"."\n\n"."اما برخی مدیران (برای عدم مزاحمت شبانه یا توقف ارسال هرگونه مطلب به کانال بخاطر تبادلات تلگرامی و ...) مایل نیستند که مطالب موجود در صف، در ساعات شبانگاهی ارسال گردد"."\n"."در صورتی که می‌خواهید این تنظیم را تغییر دهید، می‌توانید از بین زمان‌های پیشنهادی زیر، یکی را انتخاب کنید یا زمان موردنظر خود را تایپ و ارسال کنید"."\n\n"."دقت کنید که حتما باید زمان مورد نظر به صورت ساعت ۲۴ ساعته باشد"."\n"."ابتدا ساعت شروع و سپس خط تیره و سپس ساعت انتهایی را ارسال کنید"."\n\n"."🔴 به عنوان مثال: "."\n"."08:00-23:00"."\n\n"."تنظیم فعلی شما : "."\n".file_get_contents("config/time.txt"),
					'reply_markup' => $keyboard->go_back()
					]);
				}
			}
		}
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML",
		'reply_markup' => $keyboard->key_start()
		]);
	}
/*

📌 کانال ایلیا سورس
برای دریافت سورس های بیشتر به کانال ما سر بزنید :)
@Source_Eliya

*/