<?php
	require_once dirname(__FILE__) . '/../../../autoload.php';
	
	if(in_array($data->user_id, $auth->admin_list))
	{
		if ( $constants->last_message === null ) 
		{
			$database->update("member", [ 'last_query' => 'addSign' ],["id" => $data->user_id]);
			
			if(file_get_contents("config/signature.txt")==1)
			{
				$statusOld=$keyboard->buttons['yes'];
			}
			else
			{
				$statusOld=$keyboard->buttons['no'];
			}
			
			$telegram->sendMessage([
			'chat_id' => $data->chat_id,
			'text' => "شما همواره امکان تعریف و ویرایش امضا برای کانال های ثبت شده را دارید"."\n"."در این قسمت از تنظیمات، شما می‌توانید تعیین کنید که امضا، همیشه به صورت اتوماتیک به متن و کپشن تصاویر شما اضافه شود یا خیر"."\n"."دقت کنید که فعال بودن امضاء خودکار، ممکن است موجب اختلال در کپشن تصویر/ویدئو/فایل شود چون کپشن محدود به 200 کاراکتر است و اگر شما تنظیم کنید که امضا به آن الصاق شود، ممکن است کپشن مطلب مذکور بُرش بخورد تا بتواند امضای شما هم در کپشن گنجانده شود"."\n"."لذا چنانچه در کار تصویر و کلیپ و فایل زیرنویس‌دار هستید شاید بهتر باشد این قابلیت را خاموش کنید"."\n\n"."❓ وضعیت فعلی : ".$statusOld,
			'reply_markup' => $keyboard->key_confirm()
			]);
		}
		elseif ( $constants->last_message == 'addSign' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "گزینه مورد نظر را انتخاب نمایید:",
				'reply_markup' => $keyboard->key_setting()
				]);
			} 
			else 
			{
				if($data->text==$keyboard->buttons['yes'] or $data->text==$keyboard->buttons['no'])
				{
					$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
					
					if($data->text==$keyboard->buttons['yes'])
					{
						$status=1;
					}
					else
					{
						$status=0;
					}
					
					file_put_contents("config/signature.txt",$status);
					
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'parse_mode' => 'Markdown',
					'text' => "✅ وضعیت جدید باموفقیت ثبت شد.",
					'reply_markup' => $keyboard->key_setting()
					]);
				}
				else
				{
					$database->update("member", [ 'last_query' => 'addSign' ],["id" => $data->user_id]);
					
					if(file_get_contents("config/signature.txt")==1)
					{
						$statusOld=$keyboard->buttons['yes'];
					}
					else
					{
						$statusOld=$keyboard->buttons['no'];
					}
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'text' => "⚠️ یکی از گزینه های زیر را می بایست انتخاب نمایید."."\n\n"."شما همواره امکان تعریف و ویرایش امضا برای کانال های ثبت شده را دارید"."\n"."در این قسمت از تنظیمات، شما می‌توانید تعیین کنید که امضا، همیشه به صورت اتوماتیک به متن و کپشن تصاویر شما اضافه شود یا خیر"."\n"."دقت کنید که فعال بودن امضاء خودکار، ممکن است موجب اختلال در کپشن تصویر/ویدئو/فایل شود چون کپشن محدود به 200 کاراکتر است و اگر شما تنظیم کنید که امضا به آن الصاق شود، ممکن است کپشن مطلب مذکور بُرش بخورد تا بتواند امضای شما هم در کپشن گنجانده شود"."\n"."لذا چنانچه در کار تصویر و کلیپ و فایل زیرنویس‌دار هستید شاید بهتر باشد این قابلیت را خاموش کنید"."\n\n"."❓ وضعیت فعلی : ".$statusOld,
					'reply_markup' => $keyboard->key_confirm()
					]);
				}
			}
		}
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML",
		'reply_markup' => $keyboard->key_start()
		]);
	}
 