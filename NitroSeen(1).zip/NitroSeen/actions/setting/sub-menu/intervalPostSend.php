<?php
	require_once dirname(__FILE__) . '/../../../autoload.php';
	
	function convertNumbers($srting,$toPersian=false)
	{
		$en_num = array('0','1','2','3','4','5','6','7','8','9');
		$fa_num = array('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹');
		if($toPersian)
		return str_replace($en_num, $fa_num, $srting);
        else 
		return str_replace($fa_num, $en_num, $srting);
	}
	
	function stringToArray($jobs = '')
	{
        $array = explode("\r\n", trim($jobs));
        foreach ($array as $key => $item)
		{
            if ($item == '') 
			{
                unset($array[$key]);
			}
		}
        return $array;
	}
    
    function arrayToString($jobs = array()) 
	{
        $string = implode("\r\n", $jobs);
        return $string;
	}
    
    function getJobs()
	{
        $output = shell_exec('crontab -l');
        return stringToArray($output);
	}
    
    function saveJobs($jobs = array())
	{
        $output = shell_exec('echo "'.arrayToString($jobs).'" | crontab -');
        return $output;	
	}
    
    function doesJobExist($job = '')
	{
        $jobs = getJobs();
		//file_put_contents("txt.json",$jobs);
        if (in_array($job, $jobs))
		{
            return true;
		}
		else
		{
            return false;
		}
	}
    
    function addJob($job = '') 
	{
        if (doesJobExist($job)) 
		{
            return false;
		} 
		else
		{
            $jobs = getJobs();
            $jobs[] = $job;
            return saveJobs($jobs);
		}
	}
    
    function removeJob($job = '')
	{
        if (doesJobExist($job))
		{
            $jobs = getJobs();
            unset($jobs[array_search($job, $jobs)]);
            return saveJobs($jobs);
		} 
		else 
		{
            return false;
		}
	}
	
	if(in_array($data->user_id, $auth->admin_list))
	{
		if ( $constants->last_message === null ) 
		{
			$catInfo = $database->query("SELECT channel FROM `channel` where status=1 order by channel ASC");
			
			$database->update('member', ['last_query' => 'channelInterval'], ['id' => $data->user_id]);	
			while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
			{
				$keys[] = $item_type['channel'];
			}
			
			$count=count($keys);
			if($count%2==0)
			{
				array_push($keys,"",$keyboard->buttons['go_back']);
			}
			else
			{
				array_push($keys,$keyboard->buttons['go_back']);
			}
			$j=0;
			$i=1;
			for($d=0;$d<=$count/2;$d++)
			{
				$options[]=array($keys[$i],$keys[$j]);
				$j=$j+2;
				$i=$i+2;
			}
			
			if( $options[0][0] !=null && $options[0][1] !=null )
			{
				$keyboard = Array(
				'keyboard' => $options ,
				'resize_keyboard' => true ,
				'one_time_keyboard' => false ,
				'selective' => true
				);
				
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'disable_web_page_preview' => 'true',
				'text' => "✅ لطفا کانال مورد نظر خود را انتخاب نمایید:",
				'reply_markup' => json_encode($keyboard)
				]);
			}
			else
			{
				$database->update('member', ['last_query' => null], ['id' => $data->user_id]);	
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'disable_web_page_preview' => 'true',
				'text' => "⚠️ متاسفانه در حال حاضر کانالی وجود ندارد.",
				'reply_markup' => $keyboard->key_setting()
				]);
			}
		}
		elseif ( $constants->last_message == 'channelInterval' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "گزینه مورد نظر را انتخاب نمایید:",
				'reply_markup' => $keyboard->key_setting()
				]);
			}
			else 
			{
				if($database->has("channel", ["channel" => $data->text]))
				{
					$database->update("member", [ 'last_query' => 'intervalPostSend','last_request' => $data->text ],["id" => $data->user_id]);
					
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'text' => "🕰 در این بخش می توانید تعیین کنید که ربات هر چند مدت به سراغ صف ارسال برود."."\n\n"."به عنوان مثال چنانچه شما هر 5 دقیقه را انتخاب نمایید هر 5 دقیقه ربات به سراغ صف ارسال شما رفته و تعداد مطالبی را که مشخص کرده اید در کانال ارسال می کند."."\n\n"."زمانبندی فعلی : ".(file_get_contents("config/interval/".$data->text."/interval.txt")!="" ? file_get_contents("config/interval/".$data->text."/interval.txt"):"-"),
					'reply_markup' => $keyboard->key_interval()
					]);
				}
				else
				{
					$database->update('member', ['last_query' => 'channelInterval'], ['id' => $data->user_id]);	
					
					$catInfo = $database->query("SELECT channel FROM `channel` where status=1 order by channel ASC");
					while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
					{
						$keys[] = $item_type['channel'];
					}
					
					$count=count($keys);
					if($count%2==0)
					{
						array_push($keys,"",$keyboard->buttons['go_back']);
					}
					else
					{
						array_push($keys,$keyboard->buttons['go_back']);
					}
					$j=0;
					$i=1;
					for($d=0;$d<=$count/2;$d++)
					{
						$options[]=array($keys[$i],$keys[$j]);
						$j=$j+2;
						$i=$i+2;
					}
					
					if( $options[0][0] !=null && $options[0][1] !=null )
					{
						$keyboard = Array(
						'keyboard' => $options ,
						'resize_keyboard' => true ,
						'one_time_keyboard' => false ,
						'selective' => true
						);
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "✅ لطفا کانال مورد نظر خود را انتخاب نمایید:",
						'reply_markup' => json_encode($keyboard)
						]);
					}
					else
					{
						$database->update('member', ['last_query' => null], ['id' => $data->user_id]);	
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "⚠️ متاسفانه در حال حاضر کانالی وجود ندارد.",
						'reply_markup' => $keyboard->key_setting()
						]);
					}
				}
			}
		}
		elseif ( $constants->last_message == 'intervalPostSend' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update('member', ['last_query' => 'channelInterval'], ['id' => $data->user_id]);	
				
				$catInfo = $database->query("SELECT channel FROM `channel` where status=1 order by channel ASC");
				while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
				{
					$keys[] = $item_type['channel'];
				}
				
				$count=count($keys);
				if($count%2==0)
				{
					array_push($keys,"",$keyboard->buttons['go_back']);
				}
				else
				{
					array_push($keys,$keyboard->buttons['go_back']);
				}
				$j=0;
				$i=1;
				for($d=0;$d<=$count/2;$d++)
				{
					$options[]=array($keys[$i],$keys[$j]);
					$j=$j+2;
					$i=$i+2;
				}
				
				if( $options[0][0] !=null && $options[0][1] !=null )
				{
					$keyboard = Array(
					'keyboard' => $options ,
					'resize_keyboard' => true ,
					'one_time_keyboard' => false ,
					'selective' => true
					);
					
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'parse_mode' => 'Markdown', 
					'disable_web_page_preview' => 'true',
					'text' => "✅ لطفا کانال مورد نظر خود را انتخاب نمایید:",
					'reply_markup' => json_encode($keyboard)
					]);
				}
				else
				{
					$database->update('member', ['last_query' => null], ['id' => $data->user_id]);	
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'parse_mode' => 'Markdown', 
					'disable_web_page_preview' => 'true',
					'text' => "⚠️ متاسفانه در حال حاضر کانالی وجود ندارد.",
					'reply_markup' => $keyboard->key_setting()
					]);
				}
			} 
			else 
			{
				if(
				$data->text==$keyboard->buttons['1min'] or
				$data->text==$keyboard->buttons['5min'] or 
				$data->text==$keyboard->buttons['15min'] or
				$data->text==$keyboard->buttons['30min'] or
				$data->text==$keyboard->buttons['45min'] or
				$data->text==$keyboard->buttons['1hour'] or
				$data->text==$keyboard->buttons['2hour'] or
				$data->text==$keyboard->buttons['3hour'] or
				$data->text==$keyboard->buttons['4hour'] or
				$data->text==$keyboard->buttons['5hour'] or
				$data->text==$keyboard->buttons['6hour'] or
				$data->text==$keyboard->buttons['7hour'] or
				$data->text==$keyboard->buttons['8hour'] or
				$data->text==$keyboard->buttons['9hour'] or
				$data->text==$keyboard->buttons['10hour'] or
				$data->text==$keyboard->buttons['11hour'] or 
				$data->text==$keyboard->buttons['12hour'] or 
				$data->text==$keyboard->buttons['deleteCronJob']
				)
				{
					if($data->text==$keyboard->buttons['deleteCronJob'])
					{
						$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
						if(file_get_contents("config/interval/".$last_request[0]['last_request']."/lastinterval.txt")!=null)
						{
							removeJob(file_get_contents("config/interval/".$last_request[0]['last_request']."/lastinterval.txt"));
							
							file_put_contents("config/interval/".$last_request[0]['last_request']."/interval.txt","");
							file_put_contents("config/interval/".$last_request[0]['last_request']."/lastinterval.txt","");
							
							$database->update("member", [ 'last_query' => null ,'last_request' => null ],["id" => $data->user_id]);
							
							$telegram->sendMessage([
							'chat_id' => $data->chat_id,
							'parse_mode' => 'Markdown',
							'text' => "✅ زمانبندی جدید باموفقیت حذف شد.",
							'reply_markup' => $keyboard->key_setting()
							]);
						}
						else
						{
							$database->update("member", [ 'last_query' => 'intervalPostSend' ],["id" => $data->user_id]);
							$telegram->sendMessage([
							'chat_id' => $data->chat_id,
							'text' => "⚠️ در حال حاضر زمانی ثبت نشده است."."\n"."می توانید یکی از زمان های زیر را انتخاب در غیر اینصورت دکمه بازگشت را انتخاب نمایید:",
							'reply_markup' => $keyboard->key_interval()
							]);
						}
					}
					else
					{				
						$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
						if(file_get_contents("config/interval/".$last_request[0]['last_request']."/lastinterval.txt")!=null)
						{
							removeJob(file_get_contents("config/interval/".$last_request[0]['last_request']."/lastinterval.txt"));
						}
						
						if($data->text==$keyboard->buttons['1min'])
						{
							$job='* * * * *';
						}
						else if($data->text==$keyboard->buttons['5min'])
						{
							$job='*/5 * * * *';
						}
						else if($data->text==$keyboard->buttons['15min'])
						{
							$job='*/15 * * * *';
						}
						else if($data->text==$keyboard->buttons['30min'])
						{
							$job='0,30 * * * *';
						}
						else if($data->text==$keyboard->buttons['45min'])
						{
							$job='*/45 * * * *';
						}
						else if($data->text==$keyboard->buttons['1hour'])
						{
							$job='0 * * * *';
						}
						else if($data->text==$keyboard->buttons['2hour'])
						{
							$job='0 */2 * * *';
						}
						else if($data->text==$keyboard->buttons['3hour'])
						{
							$job='0 */3 * * *';
						}
						else if($data->text==$keyboard->buttons['4hour'])
						{
							$job='0 */4 * * *';
						}
						else if($data->text==$keyboard->buttons['5hour'])
						{
							$job='0 */5 * * *';
						}
						else if($data->text==$keyboard->buttons['6hour'])
						{
							$job='0 */6 * * *';
						}
						else if($data->text==$keyboard->buttons['7hour'])
						{
							$job='0 */7 * * *';
						}
						else if($data->text==$keyboard->buttons['8hour'])
						{
							$job='0 */8 * * *';
						}
						else if($data->text==$keyboard->buttons['9hour'])
						{
							$job='0 */9 * * *';
						}
						else if($data->text==$keyboard->buttons['10hour'])
						{
							$job='0 */10 * * *';
						}
						else if($data->text==$keyboard->buttons['11hour'])
						{
							$job='0 */11 * * *';
						}
						else if($data->text==$keyboard->buttons['12hour'])
						{
							$job='0 0,12 * * *';
						}
						
						/*$cronJob=$job." /usr/bin/php -q /home/sajadhaj/public_html/Customer/vardast/config/interval/".$last_request[0]['last_request']."/checkpm.php";*/
						
						$cronJob=$job." curl -s ".$auth->path."config/interval/".$last_request[0]['last_request']."/checkpm.php";
						
						addJob($cronJob);
						file_put_contents("config/interval/".$last_request[0]['last_request']."/lastinterval.txt",$cronJob);
						file_put_contents("config/interval/".$last_request[0]['last_request']."/interval.txt",$data->text);
						//exec('crontab -r', $crontab);
						
						$database->update("member", [ 'last_query' => null ,'last_request' => null ],["id" => $data->user_id]);
						
						$telegram->sendMessage([
						'chat_id' => $data->chat_id,
						'parse_mode' => 'Markdown',
						'text' => "✅ زمانبندی جدید باموفقیت ثبت شد.",
						'reply_markup' => $keyboard->key_setting()
						]);
					}
				}
				else
				{
					$database->update("member", [ 'last_query' => 'intervalPostSend' ],["id" => $data->user_id]);
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'text' => "⚠️ می بایست از دکمه های زیر استفاده نمایید:",
					'reply_markup' => $keyboard->key_interval()
					]);
				}
			}
		}
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML",
		'reply_markup' => $keyboard->key_start()
		]);
	}
 