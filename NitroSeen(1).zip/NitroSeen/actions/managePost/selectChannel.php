<?php
	require_once dirname(__FILE__) . '/../../autoload.php';
	
	if(in_array($data->user_id, $auth->admin_list) or $database->has("admin", ["user" => $data->user_id]))
	{
		if ( $constants->last_message === null ) 
		{		
			$catInfo = $database->query("SELECT channel FROM `channel` where status=1 order by channel ASC");
			
			$database->update('member', ['last_query' => 'selectChannel'], ['id' => $data->user_id]);	
			while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
			{
				$keys[] = $item_type['channel'];
			}
			
			$count=count($keys);
			if($count%2==0)
			{
				array_push($keys,"",$keyboard->buttons['go_back']);
			}
			else
			{
				array_push($keys,$keyboard->buttons['go_back']);
			}
			$j=0;
			$i=1;
			for($d=0;$d<=$count/2;$d++)
			{
				$options[]=array($keys[$i],$keys[$j]);
				$j=$j+2;
				$i=$i+2;
			}
			
			if( $options[0][0] !=null && $options[0][1] !=null )
			{
				$keyboard = Array(
				'keyboard' => $options ,
				'resize_keyboard' => true ,
				'one_time_keyboard' => false ,
				'selective' => true
				);
				
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'disable_web_page_preview' => 'true',
				'text' => "✅ لطفا کانال مورد نظر خود را انتخاب نمایید:",
				'reply_markup' => json_encode($keyboard)
				]);
			}
			else
			{
				$database->update('member', ['last_query' => null], ['id' => $data->user_id]);	
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'disable_web_page_preview' => 'true',
				'text' => "⚠️ متاسفانه در حال حاضر کانالی وجود ندارد.",
				'reply_markup' => $keyboard->key_start()
				]);
			}
		}
		elseif ( $constants->last_message == 'selectChannel' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update("member", [ 'last_query' => null ], [ 'id' => $data->user_id ]);
				
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "گزینه مورد نظر را انتخاب نمایید:",
				'reply_markup' => $keyboard->key_start()
				]);
			}
			else 
			{
				if($database->has("channel", ["channel" => $data->text]))
				{
					$database->update('member', ['last_query' => null],["id" => $data->user_id]);	
					$channel='';
					$i=1;
					$catInfo = $database->query("SELECT * FROM `list` where status=0 and ch_name='".$data->text."'");
					while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
					{
						if($item_type['file_id']!="0")
						{
							$type="فایل";
						}
						else if($item_type['video_id']!="0")
						{
							$type="ویدئو";
						}
						else if($item_type['photo_id']!="0")
						{
							$type="تصویر";
						}
						else if($item_type['audio_id']!="0")
						{
							$type="موزیک";
						}
						else if($item_type['sticker_id']!="0")
						{
							$type="استیکر";
						}
						else if($item_type['voice_id']!="0")
						{
							$type="ویس";
						}
						else if($item_type['location_long']!="0")
						{
							$type="موقعیت مکانی";
						}
						else
						{
							$type="متن";
						}
						
						$channel .= $i."- ادمین: ".$item_type['admin_id']."\n"."نوع پست: ".$type."\n"."تاریخ ثبت: ".$item_type['date_created']."\n"."حذف پست: /del_".$item_type['id']."\n"."مشاهده پست: /view_".$item_type['id']."\n\n";
						$i++;
					}
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'text' => ($channel!="" ? "لیست پست های صف ارسال @".$data->text." :\n\n".$channel:"⚠️ در حال حاضر مطلبی در صف ارسال وجود ندارد."),
					"parse_mode" =>"HTML",
					'reply_markup' => $keyboard->key_start()
					]);
				}
				else
				{
					$database->update('member', ['last_query' => 'selectChannel'], ['id' => $data->user_id]);	
					
					$catInfo = $database->query("SELECT channel FROM `channel` where status=1 order by channel ASC");
					while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
					{
						$keys[] = $item_type['channel'];
					}
					
					$count=count($keys);
					if($count%2==0)
					{
						array_push($keys,"",$keyboard->buttons['go_back']);
					}
					else
					{
						array_push($keys,$keyboard->buttons['go_back']);
					}
					$j=0;
					$i=1;
					for($d=0;$d<=$count/2;$d++)
					{
						$options[]=array($keys[$i],$keys[$j]);
						$j=$j+2;
						$i=$i+2;
					}
					
					if( $options[0][0] !=null && $options[0][1] !=null )
					{
						$keyboard = Array(
						'keyboard' => $options ,
						'resize_keyboard' => true ,
						'one_time_keyboard' => false ,
						'selective' => true
						);
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "✅ لطفا کانال مورد نظر خود را انتخاب نمایید:",
						'reply_markup' => json_encode($keyboard)
						]);
					}
					else
					{
						$database->update('member', ['last_query' => null], ['id' => $data->user_id]);	
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "⚠️ متاسفانه در حال حاضر کانالی وجود ندارد.",
						'reply_markup' => $keyboard->key_start()
						]);
					}
				}
			}
		}
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "⚠️ متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML"
		]);
	}
	/*

📌 کانال ایلیا سورس
برای دریافت سورس های بیشتر به کانال ما سر بزنید :)
@Source_Eliya

*/
