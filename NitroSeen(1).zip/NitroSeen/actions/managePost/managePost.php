<?php
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
	require_once dirname(__FILE__) . '/../../autoload.php';
	
	function removeEmoji($text) 
	{
		$clean_text = "";
		
		// Match Emoticons
		$regexEmoticons = '/[\x{1F600}-\x{1F64F}]/u';
		$clean_text = preg_replace($regexEmoticons, '', $text);
		
		// Match Miscellaneous Symbols and Pictographs
		$regexSymbols = '/[\x{1F300}-\x{1F5FF}]/u';
		$clean_text = preg_replace($regexSymbols, '', $clean_text);
		
		// Match Transport And Map Symbols
		$regexTransport = '/[\x{1F680}-\x{1F6FF}]/u';
		$clean_text = preg_replace($regexTransport, '', $clean_text);
		
		// Match Miscellaneous Symbols
		$regexMisc = '/[\x{2600}-\x{26FF}]/u';
		$clean_text = preg_replace($regexMisc, '', $clean_text);
		
		// Match Dingbats
		$regexDingbats = '/[\x{2700}-\x{27BF}]/u';
		$clean_text = preg_replace($regexDingbats, '', $clean_text);
		
		return $clean_text;
	}
	
	
	if(in_array($data->user_id, $auth->admin_list) or $database->has("admin", ["user" => $data->user_id]))
	{		
		if ($data->callback_query)
		{
			$data_inline = explode("-", $data->text);		
			
			if($data_inline[0] == "send")
			{				
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>""
				]);
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$forward = $database->select('list', ['forward'], ["id" => $data_inline[1]]);
				
				$catInfo = $database->query("SELECT * FROM `list` where id=".$data_inline[1]);
				
				while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
				{
					$caption = str_replace("????","",$item_type['caption']);
					$sign = $database->select('channel', ['signature'], ['channel' => $item_type['ch_name']]);
					$text=$caption."\n".$sign[0]['signature'];
					
					if(file_get_contents("config/signature.txt")=="1")
					{
						if($sign[0]['signature']!="0")
						{
							if(strlen($caption)>=400)
							{
								$textSend=$caption;
							}
							else
							{					
								if(strlen($text)>=400)
								{
									$textSend=$caption;
								}
								else
								{
									$textSend=$text;
								}
							}
							}
						else
						{
							$textSend=$caption;
						}
					}
					else
					{
						$textSend=$caption;
					}
					
					if($forward[0]['forward']==0)
					{
						if($item_type['file_id']!="0")
						{
							$json = $telegram->sendDocument([
							'chat_id' => "@".$item_type['ch_name'],
							'document' => $item_type['file_id'],
							'caption' => $textSend ,
							"parse_mode" =>"HTML",
							'disable_notification' =>  $notificationStatus ,
							'disable_web_page_preview' => $linkStatus
							]);
						}
						else if($item_type['video_id']!="0")
						{
							$json = $telegram->sendVideo([
							'chat_id' => "@".$item_type['ch_name'],
							'video' =>  $item_type['video_id'],
							'caption' => $textSend ,
							"parse_mode" =>"HTML",
							'disable_notification' =>  $notificationStatus ,
							'disable_web_page_preview' => $linkStatus
							]);
						}
						else if($item_type['photo_id']!="0")
						{
							$json = $telegram->sendPhoto([
							'chat_id' => "@".$item_type['ch_name'],
							'photo' =>  $item_type['photo_id'],
							'caption' => $textSend ,
							"parse_mode" =>"HTML",
							'disable_notification' =>  $notificationStatus ,
							'disable_web_page_preview' => $linkStatus
							]);
						}
						else if($item_type['audio_id']!="0")
						{
							$json = $telegram->sendAudio([
							'chat_id' => "@".$item_type['ch_name'],
							'audio' =>  $item_type['audio_id'],
							'caption' => $textSend ,
							"parse_mode" =>"HTML",
							'disable_notification' =>  $notificationStatus ,
							'disable_web_page_preview' => $linkStatus
							]);
						}
						else if($item_type['sticker_id']!="0")
						{
							$json = $telegram->sendSticker([
							'chat_id' => "@".$item_type['ch_name'],
							'sticker' =>  $item_type['sticker_id'],
							"parse_mode" =>"HTML",
							'disable_notification' =>  $notificationStatus ,
							'disable_web_page_preview' => $linkStatus
							]);
						}
						else if($item_type['voice_id']!="0")
						{
							$json = $telegram->sendVoice([
							'chat_id' => "@".$item_type['ch_name'],
							'voice' =>  $item_type['voice_id'],
							'caption' => $textSend ,
							"parse_mode" =>"HTML",
							'disable_notification' =>  $notificationStatus ,
							'disable_web_page_preview' => $linkStatus
							]);
						}
						else if($item_type['location_long']!="0")
						{
							$json = $telegram->sendLocation([
							'chat_id' => "@".$item_type['ch_name'],
							'latitude' =>  $item_type['location_lat'],
							'longitude' =>  $item_type['location_long'] ,
							'disable_notification' =>  $notificationStatus ,
							'disable_web_page_preview' => $linkStatus
							]);
						}
						else
						{
							$json = $telegram->sendMessage([
							'chat_id' => "@".$item_type['ch_name'],
							'text' => $text ,
							"parse_mode" =>"HTML",
							'disable_notification' =>  $notificationStatus ,
							'disable_web_page_preview' => $linkStatus
							]);
						}
					}
					else
					{
						$json = $telegram->forwardMessage([
						'chat_id' => "@".$item_type['ch_name'],
						'from_chat_id' => $data->chat_id,
						'message_id' => $item_type['msg_id'],
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus
						]);
					}
				}
				$database->update("list", [ 'status' => 1 ],["id" => $data_inline[1]]);
				
				$telegram->editMessageText([
				'chat_id' => $data->chat_id,
				'message_id' => $data->message_id,
				'parse_mode' => 'Markdown',
				'text' => 
				'✅ باموفقیت در کانال ارسال شد.',
				'reply_markup' => $keyboard->key_del($json['result']['message_id'],$data_inline[1])
				]);
			}
			else if($data_inline[0] == "view")
			{
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>""
				]);
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$channel='';
				$i=1;
				$catInfo = $database->query("SELECT * FROM `list` where id=".$data_inline[1]);
				while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
				{
					if($item_type['file_id']!="0")
					{
						$telegram->sendDocument([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'document' => $item_type['file_id'],
						'caption' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus
						]);
					}
					else if($item_type['video_id']!="0")
					{
						$telegram->sendVideo([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'video' =>  $item_type['video_id'],
						'caption' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus
						]);
					}
					else if($item_type['photo_id']!="0")
					{
						$telegram->sendPhoto([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'photo' =>  $item_type['photo_id'],
						'caption' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus
						]);
					}
					else if($item_type['audio_id']!="0")
					{
						$telegram->sendAudio([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'audio' =>  $item_type['audio_id'],
						'caption' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus
						]);
					}
					else if($item_type['sticker_id']!="0")
					{
						$telegram->sendSticker([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'sticker' =>  $item_type['sticker_id'],
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus
						]);
					}
					else if($item_type['voice_id']!="0")
					{
						$telegram->sendVoice([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'voice' =>  $item_type['voice_id'],
						'caption' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus
						]);
					}
					else if($item_type['location_long']!="0")
					{
						$telegram->sendLocation([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'latitude' =>  $item_type['location_lat'],
						'longitude' =>  $item_type['location_long'] ,
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus
						]);
					}
					else
					{
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'text' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus
						]);
					}
				}
			}
			else if($data_inline[0] == "edit")
			{
				$telegram->editMessageReplyMarkup([
				'chat_id' => $data->user_id,
				'message_id' => $data_inline[2],
				'reply_markup' => $keyboard->key_edit($data_inline[1],$data_inline[2])
				]);
				
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>"بخش مورد نظر خود برای ویرایش را انتخاب نمایید:"
				]);
			}
			else if($data_inline[0] == "back")
			{
				$telegram->editMessageReplyMarkup([
				'chat_id' => $data->user_id,
				'message_id' => $data_inline[2],
				'reply_markup' => $keyboard->key_post($data_inline[1],$data_inline[2])
				]);
				
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>""
				]);
			}
			else if($data_inline[0] == "delLink")
			{
				$caption = $database->select('list', ['caption'], ["id" => $data_inline[1]]);
				
				$text=preg_replace("/[a-zA-Z]*[:\/\/]*[A-Za-z0-9\-_]+\.+[A-Za-z0-9\.\/%&=\?\-_]+/i", '', $caption[0]['caption']);
				
				$database->update("list", [ 'caption' => $text ],["id" => $data_inline[1]]);
				
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>$data->text
				]);
			}
			else if($data_inline[0] == "forward")
			{
				$forward = $database->select('list', ['forward'], ["id" => $data_inline[1]]);
				
				if($forward[0]['forward']==1)
				{
					$database->update("list", [ 'forward' => 0 ],["id" => $data_inline[1]]);
					$status="❌ غیرفعال";
				}
				else
				{
					$database->update("list", [ 'forward' => 1 ],["id" => $data_inline[1]]);
					$status="✅ فعال";
				}
				
				$telegram->editMessageReplyMarkup([
				'chat_id' => $data->user_id,
				'message_id' => $data_inline[2],
				'reply_markup' => $keyboard->key_edit($data_inline[1],$data_inline[2])
				]);
				
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>$status
				]);
			}
			else if($data_inline[0] == "delHashtag")
			{
				$caption = $database->select('list', ['caption'], ["id" => $data_inline[1]]);
				
				//$text=getCleanString($caption[0]['caption']);
				$text=preg_replace("/#([\p{L}\p{Mn}]+)/u", '', $caption[0]['caption']);
				$text=preg_replace("/(#)/", '', $text);
				
				$database->update("list", [ 'caption' => $text ],["id" => $data_inline[1]]);
				
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>"هشتگ ها از متن حذف شدند."
				]);
			}
			else if($data_inline[0] == "delEmoji")
			{
				$caption = $database->select('list', ['caption'], ["id" => $data_inline[1]]);
				
				$text=removeEmoji($caption[0]['caption']);
				
				$database->update("list", [ 'caption' => $text ],["id" => $data_inline[1]]);
				
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>"ایموجی ها از متن حذف شدند."
				]);
			}
			else if($data_inline[0] == "id")
			{
				$caption = $database->select('list', ['caption'], ["id" => $data_inline[1]]);
				
				$text=str_replace("_", '', $caption[0]['caption']);
				$text=preg_replace("/@([\p{L}\p{Mn}]+)/u", '', $text);
				$text=preg_replace("/(@)/", '', $text);
				
				$database->update("list", [ 'caption' => $text ],["id" => $data_inline[1]]);
				
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>"آیدی ها از متن حذف شدند."
				]);
			}
			else if($data_inline[0] == "del")
			{
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>""
				]);
				
				$database->delete("list", ["id" => $data_inline[1]]);
				
				$telegram->editMessageText([
				'chat_id' => $data->chat_id,
				'message_id' => $data->message_id,
				'parse_mode' => 'Markdown',
				'text' => '❌ از صف ارسال حذف شد!'
				]);
			}
			else if($data_inline[0] == "deletePost")
			{
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>""
				]);
				
				$database->update("list", [ 'status' => -1 ],["id" => $data_inline[2]]);
				
				$channel = $database->select('list', ['ch_name'], ["id" => $data_inline[2]]);
				$json = $telegram->deleteMessage([
				'chat_id' => "@".$channel[0]['ch_name'],
				'message_id' => $data_inline[1],
				]);
				
				if($json['result']==true)
				{
					$telegram->editMessageText([
					'chat_id' => $data->chat_id,
					'message_id' => $data->message_id,
					'parse_mode' => 'Markdown',
					'text' => '❌ از کانال حذف شد!'
					]);
				}
				else
				{
					$telegram->answerCallbackQuery([
					'callback_query_id' => $data->callback_query_id,
					'show_alert' => false,
					'text'=>"متاسفانه خطایی رخ داده است!"
					]);
				}
			}
		}
		else
		{
			$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
			
			if(preg_match('/^(\/del_)(.*)/',$data->text))
			{
				$id=str_replace("/del_","",$data->text);
				$database->delete("list", ["id" => $id]);
				
				$database->update('member', ['last_query' => null],["id" => $data->user_id]);	
				$channel='';
				$i=1;
				$catInfo = $database->query("SELECT * FROM `list` where status=0");
				while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
				{
					if($item_type['file_id']!="0")
					{
						$type="فایل";
					}
					else if($item_type['video_id']!="0")
					{
						$type="ویدئو";
					}
					else if($item_type['photo_id']!="0")
					{
						$type="تصویر";
					}
					else if($item_type['audio_id']!="0")
					{
						$type="موزیک";
					}
					else if($item_type['sticker_id']!="0")
					{
						$type="استیکر";
					}
					else if($item_type['voice_id']!="0")
					{
						$type="ویس";
					}
					else if($item_type['location_long']!="0")
					{
						$type="موقعیت مکانی";
					}
					else
					{
						$type="متن";
					}
					
					$channel .= $i."- ادمین: ".$item_type['admin_id']."\n"."نوع پست: ".$type."\n"."تاریخ ثبت: ".$item_type['date_created']."\n"."حذف پست: /del_".$item_type['id']."\n"."مشاهده پست: /view_".$item_type['id']."\n\n";
					$i++;
				}
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "لیست پست های صف ارسال:\n\n".$channel,
				"parse_mode" =>"HTML",
				'reply_markup' => $keyboard->key_start()
				]);
			}
			else if(preg_match('/^(\/view_)(.*)/',$data->text))
			{
				$id=str_replace("/view_","",$data->text);
				
				$database->update('member', ['last_query' => null],["id" => $data->user_id]);	
				
				if(file_get_contents("config/linkpreview.txt")=="1")
				{
					$linkStatus=false;
				}
				else
				{
					$linkStatus=true;
				}
				
				if(file_get_contents("config/notification.txt")=="1")
				{
					$notificationStatus=false;
				}
				else
				{
					$notificationStatus=true;
				}
				
				$channel='';
				$i=1;
				$catInfo = $database->query("SELECT * FROM `list` where id=".$id);
				while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
				{
					if($item_type['file_id']!="0")
					{
						$telegram->sendDocument([
						'chat_id' => $data->user_id,
						'document' => $item_type['file_id'],
						'caption' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus,
						'reply_markup' => $keyboard->key_post($id,($data->message_id+1))
						]);
					}
					else if($item_type['video_id']!="0")
					{
						$telegram->sendVideo([
						'chat_id' => $data->user_id,
						'video' =>  $item_type['video_id'],
						'caption' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus,
						'reply_markup' => $keyboard->key_post($id,($data->message_id+1))
						]);
					}
					else if($item_type['photo_id']!="0")
					{
						$telegram->sendPhoto([
						'chat_id' => $data->user_id,
						'photo' =>  $item_type['photo_id'],
						'caption' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus,
						'reply_markup' => $keyboard->key_post($id,($data->message_id+1))
						]);
					}
					else if($item_type['audio_id']!="0")
					{
						$telegram->sendAudio([
						'chat_id' => $data->user_id,
						'audio' =>  $item_type['audio_id'],
						'caption' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus,
						'reply_markup' => $keyboard->key_post($id,($data->message_id+1))
						]);
					}
					else if($item_type['sticker_id']!="0")
					{
						$telegram->sendSticker([
						'chat_id' => $data->user_id,
						'sticker' =>  $item_type['sticker_id'],
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus,
						'reply_markup' => $keyboard->key_post($id,($data->message_id+1))
						]);
					}
					else if($item_type['voice_id']!="0")
					{
						$telegram->sendVoice([
						'chat_id' => $data->user_id,
						'voice' =>  $item_type['voice_id'],
						'caption' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus,
						'reply_markup' => $keyboard->key_post($id,($data->message_id+1))
						]);
					}
					else if($item_type['location_long']!="0")
					{
						$telegram->sendLocation([
						'chat_id' => $data->user_id,
						'latitude' =>  $item_type['location_lat'],
						'longitude' =>  $item_type['location_long'] ,
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus,
						'reply_markup' => $keyboard->key_post($id,($data->message_id+1))
						]);
					}
					else
					{
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'text' => $item_type['caption'] ,
						"parse_mode" =>"HTML",
						'disable_notification' =>  $notificationStatus ,
						'disable_web_page_preview' => $linkStatus,
						'reply_markup' => $keyboard->key_post($id,($data->message_id+1))
						]);
					}
				}
			}
		}
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "⚠️ متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML"
		]);
	}								
	/*

📌 کانال ایلیا سورس
برای دریافت سورس های بیشتر به کانال ما سر بزنید :)
@Source_Home

*/