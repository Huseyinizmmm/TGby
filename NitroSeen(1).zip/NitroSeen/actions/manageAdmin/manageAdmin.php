<?php
/*

📌 کانال ایلیا سورس
برای دریافت سورس های بیشتر به کانال ما سر بزنید :)
@Source_Eliya

*/
	require_once dirname(__FILE__) . '/../../autoload.php';
	if(in_array($data->user_id, $auth->admin_list))
	{
		$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
		$telegram->sendMessage([
		'chat_id' => $data->chat_id,
		'text' => "بخش مورد نظر خود را انتخاب نمایید:",
		'reply_markup' => $keyboard->key_manageAdmin()
		]);
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "⚠️ متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML"
		]);
	}
/*

📌 کانال ایلیا سورس
برای دریافت سورس های بیشتر به کانال ما سر بزنید :)
@Source_Eliya

*/