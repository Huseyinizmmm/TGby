<?php
	require_once dirname(__FILE__) . '/../../../autoload.php';
	
	$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
	
	if(in_array($data->user_id, $auth->admin_list))
	{
		$database->update('member', ['last_query' => null],["id" => $data->user_id]);	
		$admins='';
		$i=1;
		$catInfo = $database->query("SELECT user,first_name FROM `admin` order by user ASC");
		while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
		{
			$admins .= $i." - ".$item_type['user']." - ".$item_type['first_name']."\n\n";
			$i++;
		}
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' => ($admins!="" ? "⚠️ لیست ادمین ها:\n\n".$admins:"⚠️ متاسفانه در حال حاضر ادمینی وجود ندارد."),
		'reply_markup' => $keyboard->key_manageAdmin()
		]);
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "⚠️ متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML"
		]);
	}	
	/*

📌 کانال ایلیا سورس
برای دریافت سورس های بیشتر به کانال ما سر بزنید :)
@Source_Eliya

*/