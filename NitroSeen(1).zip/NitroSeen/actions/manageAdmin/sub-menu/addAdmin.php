<?php
	require_once dirname(__FILE__) . '/../../../autoload.php';
	
	if(in_array($data->user_id, $auth->admin_list))
	{
		if ( $constants->last_message === null ) 
		{
			$database->update("member", [ 'last_query' => 'addAdmin' ],["id" => $data->user_id]);
			$telegram->sendMessage([
			'chat_id' => $data->chat_id,
			'text' => "✅ لطفا یک پیام از شخص مورد نظر را برای ربات فوروارد نمایید",
			'reply_markup' => $keyboard->go_back()
			]);
		}
		elseif ( $constants->last_message == 'addAdmin' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
				
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "لطفا یک گزینه را انتخاب کنید:",
				'reply_markup' => $keyboard->key_manageAdmin()
				]);
			} 
			else 
			{
				$update = json_decode(urldecode(file_get_contents('php://input')));
				$forward_from = $update->message->forward_from;
				$from_first_name = $forward_from->first_name;
				$from_id = $forward_from->id;
				if(isset($from_id))
				{
					$database->update('member', ['last_query' => null],["id" => $data->user_id]);	
					
					if($database->has("admin", ["user" => $from_id]))
					{
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'text' => "⚠️ این کاربر قبلا به عنوان ادمین ثبت شده است.",
						'reply_markup' => $keyboard->key_manageAdmin()
						]);
					}
					else
					{
						$database->insert("admin", [
						"main_admin" => $data->user_id,
						"user" => $from_id,
						"first_name" => $from_first_name,
						"status" => 0
						]);
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'text' => "✅ ادمین جدید باموفقیت ثبت شد!"."\n"."بخش مورد نظر خود را انتخاب نمایید:",
						'reply_markup' => $keyboard->key_manageAdmin()
						]);
					}
				}
				else
				{
					$database->update("member", [ 'last_query' => 'addAdmin' ],["id" => $data->user_id]);
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'text' => "⚠️ می بایست یک پیام از کاربر مورد نظر فوروارد نمایید.",
					'reply_markup' => $keyboard->go_back()
					]);
				}
			}
		}
	}	
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "⚠️ متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML"
		]);
	}
	/*

📌 کانال ایلیا سورس
برای دریافت سورس های بیشتر به کانال ما سر بزنید :)
@Source_Eliya

*/
