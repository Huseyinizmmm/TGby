<?php
	require_once dirname(__FILE__) . '/../../../autoload.php';
	if(in_array($data->user_id, $auth->admin_list))
	{
		if ($data->callback_query)
		{
			$data_inline = explode("-", $data->text);	
			
			if($data_inline[0] == "perAdmin")
			{				
				$rows = $database->select('admin', '*', ["user" => $data_inline[2]]);
				
				if($data_inline[1]=="sticker")
				{
					if($rows[0]['sticker']==0)
					{
						$database->update('admin', ['sticker' => 1], ["user" => $data_inline[2]]);
					} 
					else
					{
						$database->update('admin', ['sticker' => 0], ["user" => $data_inline[2]]);
					}
				}
				else if($data_inline[1]=="photo")
				{
					if($rows[0]['photo']==0)
					{
						$database->update('admin', ['photo' => 1], ["user" => $data_inline[2]]);
					} 
					else
					{
						$database->update('admin', ['photo' => 0], ["user" => $data_inline[2]]);
					}
				}
				else if($data_inline[1]=="video")
				{
					if($rows[0]['video']==0)
					{
						$database->update('admin', ['video' => 1], ["user" => $data_inline[2]]);
					} 
					else
					{
						$database->update('admin', ['video' => 0], ["user" => $data_inline[2]]);
					}
				}
				else if($data_inline[1]=="voice")
				{
					if($rows[0]['voice']==0)
					{
						$database->update('admin', ['voice' => 1], ["user" => $data_inline[2]]);
					} 
					else
					{
						$database->update('admin', ['voice' => 0], ["user" => $data_inline[2]]);
					}
				}
				else if($data_inline[1]=="music")
				{
					if($rows[0]['audio']==0)
					{
						$database->update('admin', ['audio' => 1], ["user" => $data_inline[2]]);
					} 
					else
					{
						$database->update('admin', ['audio' => 0], ["user" => $data_inline[2]]);
					}
				}
				else if($data_inline[1]=="file")
				{
					if($rows[0]['file']==0)
					{
						$database->update('admin', ['file' => 1], ["user" => $data_inline[2]]);
					} 
					else
					{
						$database->update('admin', ['file' => 0], ["user" => $data_inline[2]]);
					}
				}
				else if($data_inline[1]=="text")
				{
					if($rows[0]['text']==0)
					{
						$database->update('admin', ['text' => 1], ["user" => $data_inline[2]]);
					} 
					else
					{
						$database->update('admin', ['text' => 0], ["user" => $data_inline[2]]);
					}
				}
				else if($data_inline[1]=="location")
				{
					if($rows[0]['location']==0)
					{
						$database->update('admin', ['location' => 1], ["user" => $data_inline[2]]);
					} 
					else
					{
						$database->update('admin', ['location' => 0], ["user" => $data_inline[2]]);
					}
				}
				
				$rows = $database->select('admin', '*', ["user" => $data_inline[2]]);		
				if($rows[0]['sticker']=="0"){ $stickerView="🚫";} else{ $stickerView="✅";}
				if($rows[0]['photo']=="0"){ $photoView="🚫";} else{ $photoView="✅";}
				if($rows[0]['video']=="0"){ $videoView="🚫";} else{ $videoView="✅";}
				if($rows[0]['voice']=="0"){ $voiceView="🚫";} else{ $voiceView="✅";}
				if($rows[0]['audio']=="0"){ $audioView="🚫";} else{ $audioView="✅";}
				if($rows[0]['file']=="0"){ $fileView="🚫";} else{ $fileView="✅";}
				if($rows[0]['text']=="0"){ $textView="🚫";} else{ $textView="✅";}
				if($rows[0]['location']=="0"){ $locationView="🚫";} else{ $locationView="✅";}
				if($rows[0]['phone']=="0"){ $phoneView="🚫";} else{ $phoneView="✅";}
				
				
				$keyboard = array(
				'inline_keyboard' => array(
				[
				['text'=>'تنظیمات ارسال پست برای '.$data_inline[2],'callback_data'=>'perName-name']
				],
				[
				['text'=>$stickerView,'callback_data'=>'perAdmin-sticker-'.$data_inline[2]],
				['text'=>'دسترسی استیکر','callback_data'=>'perName-sticker']
				],
				[
				['text'=>$photoView,'callback_data'=>'perAdmin-photo-'.$data_inline[2]],
				['text'=>'دسترسی عکس','callback_data'=>'perName-photo']
				],
				[
				['text'=>$videoView,'callback_data'=>'perAdmin-video-'.$data_inline[2]],
				['text'=>'دسترسی ویدئو','callback_data'=>'perName-video']
				],
				[
				['text'=>$voiceView,'callback_data'=>'perAdmin-voice-'.$data_inline[2]],
				['text'=>'دسترسی ویس','callback_data'=>'perName-voice']
				],
				[
				['text'=>$audioView,'callback_data'=>'perAdmin-music-'.$data_inline[2]],
				['text'=>'دسترسی موزیک','callback_data'=>'perName-music']
				],
				[
				['text'=>$fileView,'callback_data'=>'perAdmin-file-'.$data_inline[2]],
				['text'=>'دسترسی فایل','callback_data'=>'perName-file']
				],
				[
				['text'=>$textView,'callback_data'=>'perAdmin-text-'.$data_inline[2]],
				['text'=>'دسترسی متن','callback_data'=>'perName-text']
				],
				[
				['text'=>$locationView,'callback_data'=>'perAdmin-location-'.$data_inline[2]],
				['text'=>'دسترسی موقعیت مکانی','callback_data'=>'perName-location']
				]
				)
				);
				
				$telegram->editMessageReplyMarkup([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'message_id' => $data->message_id,
				'text' => "با استفاده از این بخش می توانید بر روی پست هایی که ادمین ها قرار است در کانال هایتان بفرستند محدودیت گذاشته و بر آنها نظارت کامل داشته باشید\n🚫 = قفل شده\t\t✅ = آزاد",
				'reply_markup' => json_encode($keyboard)
				]);
				
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>""
				]);
			}
			elseif($data_inline[0] == "perName")
			{
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>""
				]);
			}
		}
		else
		{
			if ( $constants->last_message === null ) 
			{
				$database->update('member', ['last_query' => 'permissionAdmin'],["id" => $data->user_id]);
				
				$catInfo = $database->query("SELECT user FROM `admin` order by user ASC");
				while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
				{
					$keys[] = $item_type['user'];
				}
				
				$count=count($keys);
				if($count%2==0)
				{
					array_push($keys,"",$keyboard->buttons['go_back']);
				}
				else
				{
					array_push($keys,$keyboard->buttons['go_back']);
				}
				$j=0;
				$i=1;
				for($d=0;$d<=$count/2;$d++)
				{
					$options[]=array($keys[$i],$keys[$j]);
					$j=$j+2;
					$i=$i+2;
				}
				
				if( $options[0][0] !=null && $options[0][1] !=null )
				{
					$keyboard = Array(
					'keyboard' => $options ,
					'resize_keyboard' => true ,
					'one_time_keyboard' => false ,
					'selective' => true
					);
					
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'parse_mode' => 'Markdown', 
					'disable_web_page_preview' => 'true',
					'text' => "✅ لطفا ادمین مورد نظر خود را انتخاب نمایید:",
					'reply_markup' => json_encode($keyboard)
					]);
				}
				else
				{
					$database->update('member', ['last_query' => null],["id" => $data->user_id]);	
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'parse_mode' => 'Markdown', 
					'disable_web_page_preview' => 'true',
					'text' => "⚠️ متاسفانه در حال حاضر ادمینی وجود ندارد.",
					'reply_markup' => $keyboard->key_manageAdmin()
					]);
				}
			} 
			elseif ( $constants->last_message == 'permissionAdmin' ) 
			{
				if ( $data->text == $keyboard->buttons['go_back'] ) 
				{
					$database->update("member", ['last_query' => null],["id" => $data->user_id]);
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'text' => "گزینه مورد نظر را انتخاب نمایید:",
					'reply_markup' => $keyboard->key_manageAdmin()
					]);
				} 
				else if($database->has("admin",["user" => $data->text]))
				{
					$database->update("member", ['last_query' => 'permissionAdmin'],["id" => $data->user_id]);
					
					$rows = $database->select('admin', '*',["user" => $data->text]);
					if($rows[0]['sticker']=="0"){ $stickerView="🚫";} else{ $stickerView="✅";}
					if($rows[0]['photo']=="0"){ $photoView="🚫";} else{ $photoView="✅";}
					if($rows[0]['video']=="0"){ $videoView="🚫";} else{ $videoView="✅";}
					if($rows[0]['voice']=="0"){ $voiceView="🚫";} else{ $voiceView="✅";}
					if($rows[0]['audio']=="0"){ $audioView="🚫";} else{ $audioView="✅";}
					if($rows[0]['file']=="0"){ $fileView="🚫";} else{ $fileView="✅";}
					if($rows[0]['text']=="0"){ $textView="🚫";} else{ $textView="✅";}
					if($rows[0]['location']=="0"){ $locationView="🚫";} else{ $locationView="✅";}
					$keyboard = array(
					'inline_keyboard' => array(
					[
					['text'=>'تنظیمات ارسال پست برای '.$data->text,'callback_data'=>'perName-name']
					],
					[
					['text'=>$stickerView,'callback_data'=>'perAdmin-sticker-'.$data->text],
					['text'=>'دسترسی استیکر','callback_data'=>'perName-sticker']
					],
					[
					['text'=>$photoView,'callback_data'=>'perAdmin-photo-'.$data->text],
					['text'=>'دسترسی عکس','callback_data'=>'perName-photo']
					],
					[
					['text'=>$videoView,'callback_data'=>'perAdmin-video-'.$data->text],
					['text'=>'دسترسی ویدئو','callback_data'=>'perName-video']
					],
					[
					['text'=>$voiceView,'callback_data'=>'perAdmin-voice-'.$data->text],
					['text'=>'دسترسی ویس','callback_data'=>'perName-voice']
					],
					[
					['text'=>$audioView,'callback_data'=>'perAdmin-music-'.$data->text],
					['text'=>'دسترسی موزیک','callback_data'=>'perName-music']
					],
					[
					['text'=>$fileView,'callback_data'=>'perAdmin-file-'.$data->text],
					['text'=>'دسترسی فایل','callback_data'=>'perName-file']
					],
					[
					['text'=>$textView,'callback_data'=>'perAdmin-text-'.$data->text],
					['text'=>'دسترسی متن','callback_data'=>'perName-text']
					],
					[
					['text'=>$locationView,'callback_data'=>'perAdmin-location-'.$data->text],
					['text'=>'دسترسی موقعیت مکانی','callback_data'=>'perName-location']
					]
					)
					);
					
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'parse_mode' => 'Markdown', 
					'text' => "با استفاده از این بخش می توانید بر روی پست هایی که ادمین ها قرار است در کانال هایتان بفرستند محدودیت گذاشته و بر آنها نظارت کامل داشته باشید\n🚫 = قفل شده\t\t✅ = آزاد",
					'reply_markup' => json_encode($keyboard)
					]);
				}
				else
				{
					$database->update('member', ['last_query' => 'permissionAdmin'],["id" => $data->user_id]);	
					
					$catInfo = $database->query("SELECT user FROM `admin` order by user ASC");
					while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
					{
						$keys[] = $item_type['user'];
					}
					
					$count=count($keys);
					if($count%2==0)
					{
						array_push($keys,"",$keyboard->buttons['go_back']);
					}
					else
					{
						array_push($keys,$keyboard->buttons['go_back']);
					}
					$j=0;
					$i=1;
					for($d=0;$d<=$count/2;$d++)
					{
						$options[]=array($keys[$i],$keys[$j]);
						$j=$j+2;
						$i=$i+2;
					}
					
					if( $options[0][0] !=null && $options[0][1] !=null )
					{
						$keyboard = Array(
						'keyboard' => $options ,
						'resize_keyboard' => true ,
						'one_time_keyboard' => false ,
						'selective' => true
						);
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "🚫 از دکمه های زیر استفاده کنید."."\n\n"."✅ لطفا ادمین مورد نظر خود را انتخاب نمایید:",
						'reply_markup' => json_encode($keyboard)
						]);
					}
					else
					{
						$database->update('member', ['last_query' => null],["id" => $data->user_id]);	
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "⚠️ متاسفانه در حال حاضر ادمینی وجود ندارد.",
						'reply_markup' => $keyboard->key_manageAdmin()
						]);
					}
				}
			}
			
		}
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML",
		'reply_markup' => $keyboard->key_start()
		]);
	}
	/*

📌 کانال ایلیا سورس
برای دریافت سورس های بیشتر به کانال ما سر بزنید :)
@Source_Eliya

*/
