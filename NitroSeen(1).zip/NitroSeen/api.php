﻿<?php
// توجه کنید: ست وبهوک باید رو این فایل انجام شود.

/*
این سورس
توسط : @DevHamidReza
در کانال : @souresphp
باگ گیری شده است.
*/

	ignore_user_abort(1); // run script in background
	set_time_limit(0); // run script forever 	
	ini_set("log_errors", 0);
	require_once 'autoload.php';
	date_default_timezone_set('Asia/Tehran');
	
	if((in_array($data->user_id, $auth->admin_list) or $database->has("admin", ["user" => $data->user_id])) && $data->user_id!=null)
	{
		$database->insert("member", [
		"id" => $data->user_id,
		"username" => $data->username,
		"first_name" => $data->first_name,
		"last_name" => $data->last_name,
		'date_created' => jdate("Y/n/d")
		]);
	}
	
	if(in_array($data->user_id, $auth->admin_list) or $database->has("admin", ["user" => $data->user_id]))
	{	
		if($data->callback_query)
		{
			switch ($data->text) 
			{
				case (preg_match('/perAdmin-.*/', $data->text) ? true : false):
				case (preg_match('/perName-.*/', $data->text) ? true : false):
				require_once 'actions/manageAdmin/sub-menu/permissionAdmin.php';
				break;
				case "stats-refresh":
				require_once 'actions/stats/stats.php';
				break;
				case (preg_match('/send-.*/', $data->text) ? true : false):
				case (preg_match('/view-.*/', $data->text) ? true : false):
				case (preg_match('/edit-.*/', $data->text) ? true : false):
				case (preg_match('/del-.*/', $data->text) ? true : false):
				case (preg_match('/deletePost-.*/', $data->text) ? true : false):
				case (preg_match('/delLink-.*/', $data->text) ? true : false):
				case (preg_match('/forward-.*/', $data->text) ? true : false):
				case (preg_match('/delHashtag-.*/', $data->text) ? true : false):
				case (preg_match('/delEmoji-.*/', $data->text) ? true : false):
				case (preg_match('/back-.*/', $data->text) ? true : false):
				case (preg_match('/id-.*/', $data->text) ? true : false):
				require_once 'actions/managePost/managePost.php';
				break;
			}
		}
		else if ($constants->last_message !== null && $data->text != '/start') 
		{
			switch ($constants->last_message)
			{
				case 'getPost':
				require_once 'actions/getPost/getPost.php';
				break;
				case 'channel':
				require_once 'actions/channel/channel.php';
				break;
				case 'addAdmin':
				require_once 'actions/manageAdmin/sub-menu/addAdmin.php';
				break;
				case 'addChannel':
				require_once 'actions/manageChannel/sub-menu/addChannel.php';
				break;
				case 'submitSignature':
				require_once 'actions/manageChannel/sub-menu/addSignature.php';
				break;
				case 'delAdmin':
				require_once 'actions/manageAdmin/sub-menu/delAdmin.php';
				break;
				case 'delChannel':
				require_once 'actions/manageChannel/sub-menu/delChannel.php';
				break;
				case 'addSignature':
				require_once 'actions/manageChannel/sub-menu/addSignature.php';
				break;
				case 'permissionAdmin':
				require_once 'actions/manageAdmin/sub-menu/permissionAdmin.php';
				break;
				case 'countPost':
				require_once 'actions/setting/sub-menu/countPost.php';
				break;
				case 'watermarkPhoto':
				require_once 'actions/setting/sub-menu/watermarkPhoto.php';
				break;
				case 'timeSend':
				require_once 'actions/setting/sub-menu/timeSend.php';
				break;
				case 'previewLink':
				require_once 'actions/setting/sub-menu/previewLink.php';
				break;
				case 'intervalPostSend':
				require_once 'actions/setting/sub-menu/intervalPostSend.php';
				break;
				case 'channelInterval':
				require_once 'actions/setting/sub-menu/intervalPostSend.php';
				break;
				case 'notification':
				require_once 'actions/setting/sub-menu/notification.php';
				break;
				case 'orderPost':
				require_once 'actions/setting/sub-menu/orderPost.php';
				break;
				case 'addSign':
				require_once 'actions/setting/sub-menu/addSign.php';
				break;
				case 'replaceID':
				require_once 'actions/setting/sub-menu/replaceID.php';
				break;
				case "selectChannel":
				require_once 'actions/managePost/selectChannel.php';
				break;
				
				default:
				require_once 'actions/start.php';
				break;
			}

		} 
		else
		{
			switch ($data->text) 
			{
				case '/start':
				require_once 'actions/start.php';
				break;
				case $keyboard->buttons['setting']:
				require_once 'actions/setting/setting.php';
				break;
				case $keyboard->buttons['help']:
				require_once 'actions/help/help.php';
				break;
				case $keyboard->buttons['go_back']:
				require_once 'actions/start.php';
				break;
				case $keyboard->buttons['stats']:
				require_once 'actions/stats/stats.php';
				break;
				case $keyboard->buttons['getPost']:
				require_once 'actions/channel/channel.php';
				break;
				case (preg_match('/^(\/del_)(.*)/', $data->text) ? true : false):
				case (preg_match('/^(\/view_)(.*)/', $data->text) ? true : false):
				require_once 'actions/managePost/managePost.php';
				break;
				case $keyboard->buttons['managePost']:
				require_once 'actions/managePost/selectChannel.php';
				break;
				case $keyboard->buttons['manageAdmin']:
				require_once 'actions/manageAdmin/manageAdmin.php';
				break;
				case $keyboard->buttons['manageChannel']:
				require_once 'actions/manageChannel/manageChannel.php';
				break;
				case $keyboard->buttons['listChannel']:
				require_once 'actions/manageChannel/sub-menu/listChannel.php';
				break;
				case $keyboard->buttons['delChannel']:
				require_once 'actions/manageChannel/sub-menu/delChannel.php';
				break;
				case $keyboard->buttons['addAdmin']:
				require_once 'actions/manageAdmin/sub-menu/addAdmin.php';
				break;
				case $keyboard->buttons['addChannel']:
				require_once 'actions/manageChannel/sub-menu/addChannel.php';
				break;
				case $keyboard->buttons['addSignature']:
				require_once 'actions/manageChannel/sub-menu/addSignature.php';
				break;
				case $keyboard->buttons['listAdmin']:
				require_once 'actions/manageAdmin/sub-menu/listAdmin.php';
				break;
				case $keyboard->buttons['delAdmin']:
				require_once 'actions/manageAdmin/sub-menu/delAdmin.php';
				break;
				case $keyboard->buttons['permissionAdmin']:
				require_once 'actions/manageAdmin/sub-menu/permissionAdmin.php';
				break;
				case $keyboard->buttons['countPost']:
				require_once 'actions/setting/sub-menu/countPost.php';
				break;
				case $keyboard->buttons['watermarkPhoto']:
				require_once 'actions/setting/sub-menu/watermarkPhoto.php';
				break;
				case $keyboard->buttons['timeSend']:
				require_once 'actions/setting/sub-menu/timeSend.php';
				break;
				case $keyboard->buttons['previewLink']:
				require_once 'actions/setting/sub-menu/previewLink.php';
				break;
				case $keyboard->buttons['notification']:
				require_once 'actions/setting/sub-menu/notification.php';
				break;
				case $keyboard->buttons['intervalPostSend']:
				require_once 'actions/setting/sub-menu/intervalPostSend.php';
				break;
				case $keyboard->buttons['orderPost']:
				require_once 'actions/setting/sub-menu/orderPost.php';
				break;
				case $keyboard->buttons['addSign']:
				require_once 'actions/setting/sub-menu/addSign.php';
				break;
				case $keyboard->buttons['replaceID']:
				require_once 'actions/setting/sub-menu/replaceID.php';
				break;
				
				default:
				require_once 'actions/start.php';
				break;
			}
		}
	}	
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "⚠️ متاسفانه شما اجازه دسترسی به این ربات را ندارید.",
		"parse_mode" =>"HTML"
		]);
	}	

/*
این سورس
توسط : @DevHamidReza
در کانال : @souresphp
باگ گیری شده است.
*/