﻿<?php
 
	class keyboard
	{
		public $buttons = [
        'help'                          => '⚠️ راهنما',
        'getPost'                       => '📬 ارسال مطالب',
        'managePost'                    => '🗂 مدیریت مطالب',
        'refresh'                       => '🔄 به روزرسانی',
        'manageAdmin'                   => '👤 مدیریت ادمین',
        'manageChannel'                 => '📣 مدیریت کانال',
        'addChannel'                    => '📣 افزودن کانال',
        'listChannel'                   => '📣 لیست کانال ها',
        'delChannel'                    => '❌ حذف کانال',
        'setting'                       => '⚙️ تنظیمات',
        'endPost'                       => '🔚 پایان',
        'stats'                         => '📊 آمار',
        'addAdmin'                      => '👤 افزودن ادمین',
        'addSignature'                  => '📝 امضا اختصاصی',
        'listAdmin'                     => '👥 لیست ادمین ها',
        'delAdmin'                      => '❌ حذف ادمین',
        'preview'                       => '👁 پیش نمایش',
        'sendUrgent'                    => '📮 ارسال فوری',
        'edit'                          => '✏ ویرایش',
        'delete'                        => '❌ حذف از صف',
        'delPost'                       => '❌ حذف از کانال',
        'permissionAdmin'               => '📂 فایل های مجاز',
        'countPost'                     => '📑 تعداد مطالب ارسالی',
        'watermarkPhoto'                => '🖼 واتر مارک تصاویر',
        'timeSend'                      => '⏰ ساعت مجاز ارسال',
        'previewLink'                   => '⛓ پیش نمایش لینک',
        'intervalPostSend'              => '🕰 فاصله زمانی ارسال',
        'replaceID'                     => '🆔 جایگزینی شناسه',
        'orderPost'                     => '🔀 ترتیب ارسال مطالب',
        'notification'                  => '🔊 آگاه سازی کاربر',
        'addSign'                       => '📝 امضای خودکار',
        'yes'                           => '✅ بله',
        'no'                            => '❌ خیر',
        '1min'                          => 'هر 1 دقیقه',
        '5min'                          => 'هر 5 دقیقه',
        '15min'                         => 'هر 15 دقیقه',
        '30min'                         => 'هر 30 دقیقه',
        '45min'                         => 'هر 45 دقیقه',
        '1hour'                         => 'هر 1 ساعت',
        '2hour'                         => 'هر 2 ساعت',
        '3hour'                         => 'هر 3 ساعت',
        '4hour'                         => 'هر 4 ساعت',
        '5hour'                         => 'هر 5 ساعت',
        '6hour'                         => 'هر 6 ساعت',
        '7hour'                         => 'هر 7 ساعت',
        '8hour'                         => 'هر 8 ساعت',
        '9hour'                         => 'هر 9 ساعت',
        '10hour'                        => 'هر 10 ساعت',
        '11hour'                        => 'هر 11 ساعت',
        '12hour'                        => 'هر 12 ساعت',
        'deleteCronJob'                 => 'حذف فاصله زمانی',
        'delEmoji'                      => '🙄 حذف ایموجی',
        'delHashtag'                    => '#️⃣ حذف هشتگ',
        'delLink'                       => '🔗 حذف لینک ها',
        'forward'                       => '↗️ حالت فوروارد',
        'id'                            => '🆔 حذف آیدی',
        'random'                        => 'تصادفی',
        'new'                           => 'مطلب جدیدتر',
        'old'                           => 'مطلب قدیمی تر',
        'endPost'                       => '🔚 پایان',
        'go_back'                       => '➡️ بازگشت'
		];
		
		
		public function key_start()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['getPost'] . '"
			],
			[
			"' . $this->buttons['setting'] . '",
			"' . $this->buttons['managePost'] . '"
			],
			[
			"' . $this->buttons['manageChannel'] . '",
			"' . $this->buttons['manageAdmin'] . '"
			],
			[
			"' . $this->buttons['help'] . '",
			"' . $this->buttons['stats'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true 
			}
			}';
		}
		
		
		public function key_manageAdmin()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['addAdmin'] . '",
			"' . $this->buttons['listAdmin'] . '"
			],
			[
			"' . $this->buttons['delAdmin'] . '",
			"' . $this->buttons['permissionAdmin'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_manageChannel()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['addChannel'] . '",
			"' . $this->buttons['listChannel'] . '"
			],
			[
			"' . $this->buttons['addSignature'] . '",
			"' . $this->buttons['delChannel'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_setting()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['countPost'] . '",
			"' . $this->buttons['intervalPostSend'] . '"
			],
			[
			"' . $this->buttons['replaceID'] . '",
			"' . $this->buttons['watermarkPhoto'] . '"
			],
			[
			"' . $this->buttons['timeSend'] . '",
			"' . $this->buttons['previewLink'] . '"
			],
			[
			"' . $this->buttons['notification'] . '",
			"' . $this->buttons['orderPost'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '",
			"' . $this->buttons['addSign'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_confirm()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['no'] . '",
			"' . $this->buttons['yes'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_order()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['new'] . '",
			"' . $this->buttons['old'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '",
			"' . $this->buttons['random'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_interval()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['5min'] . '",
			"' . $this->buttons['1min'] . '"
			],
			[
			"' . $this->buttons['30min'] . '",
			"' . $this->buttons['15min'] . '"
			],
			[
			"' . $this->buttons['1hour'] . '",
			"' . $this->buttons['45min'] . '"
			],
			[
			"' . $this->buttons['3hour'] . '",
			"' . $this->buttons['2hour'] . '"
			],
			[
			"' . $this->buttons['5hour'] . '",
			"' . $this->buttons['4hour'] . '"
			],
			[
			"' . $this->buttons['7hour'] . '",
			"' . $this->buttons['6hour'] . '"
			],
			[
			"' . $this->buttons['9hour'] . '",
			"' . $this->buttons['8hour'] . '"
			],
			[
			"' . $this->buttons['11hour'] . '",
			"' . $this->buttons['10hour'] . '"
			],
			[
			"' . $this->buttons['deleteCronJob'] . '",
			"' . $this->buttons['12hour'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_stats()
		{
			$keyboard = array(
			'inline_keyboard' => array(
			[
			['text'=>$this->buttons['refresh'],'callback_data'=>"stats-refresh"]
			]
			)
			);
			return  json_encode($keyboard);
		}
		
		
		public function key_post($id,$msgID)
		{
			$keyboard = array(
			'inline_keyboard' => array(
			[
			['text'=>$this->buttons['sendUrgent'],'callback_data'=>"send-".$id."-".$msgID],
			['text'=>$this->buttons['preview'],'callback_data'=>"view-".$id."-".$msgID]
			],
			[
			['text'=>$this->buttons['delete'],'callback_data'=>"del-".$id."-".$msgID],
			['text'=>$this->buttons['edit'],'callback_data'=>"edit-".$id."-".$msgID]
			]
			)
			);
			return  json_encode($keyboard);
		}
		
		
		public function key_del($msgID,$id)
		{
			$keyboard = array(
			'inline_keyboard' => array(
			[
			['text'=>$this->buttons['delPost'],'callback_data'=>"deletePost-".$msgID."-".$id]
			]
			)
			);
			return  json_encode($keyboard);
		}
		
		
		public function key_edit($id,$msgID)
		{
			$keyboard = array(
			'inline_keyboard' => array(
			[
			['text'=>$this->buttons['forward'],'callback_data'=>"forward-".$id."-".$msgID],
			['text'=>$this->buttons['delEmoji'],'callback_data'=>"delEmoji-".$id."-".$msgID]
			],
			[
			['text'=>$this->buttons['delHashtag'],'callback_data'=>"delHashtag-".$id."-".$msgID],
			['text'=>$this->buttons['delLink'],'callback_data'=>"delLink-".$id."-".$msgID]
			],
			[
			['text'=>$this->buttons['go_back'],'callback_data'=>"back-".$id."-".$msgID],
			['text'=>$this->buttons['id'],'callback_data'=>"id-".$id."-".$msgID]
			]
			)
			);
			return  json_encode($keyboard);
		}
		
		
		public function go_back()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['go_back'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function go_back_end()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['go_back'] . '",
			"' . $this->buttons['endPost'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
	}